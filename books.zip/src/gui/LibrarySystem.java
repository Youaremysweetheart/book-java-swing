package gui;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.util.stream.Collectors;



// 主类
public class LibrarySystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            //创建登录界面实例
            LoginUI loginUI = new LoginUI();
            loginUI.show();
        });
    }
}

// 用户类
class User {
    private String username;//用户名
    private String password;//用户密码
    private String role; // "user" 或 "admin",管理员或者用户学生
    private List<Book> borrowedBooks = new ArrayList<>();// 存储借阅的书籍

    // 用户构造函数，初始化用户名、密码和角色
    public User(String username, String password, String role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }
    //获取用户名
    public String getUsername() {
        return username;
    }
    // 获取密码
    public String getPassword() {
        return password;
    }
    //获取用户权限
    public String getRole() {
        return role;
    }
    //判断是否为管理员
    public boolean isAdmin() {
        return "admin".equals(role);
    }
    // 获取已借阅书籍列表
    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }
    //借书
    public void borrowBook(Book book) {
        if (book != null && !book.isBorrowed()) {
            book.setBorrowed(true);
            book.setBorrowedBy(this);
            borrowedBooks.add(book);
        }
    }
    //还书
    public void returnBook(Book book) {
        if (book != null && book.isBorrowed() && book.getBorrowedBy().equals(this)) {
            book.setBorrowed(false);
            book.setBorrowedBy(null);
            borrowedBooks.remove(book);
        }
    }
}

// 用户管理类
class UserManager {
    private static List<User> users = new ArrayList<>();
    private static User loggedInUser = null;

    static {
        // 默认管理员，可以借助数据库修改，具体操作看你
        users.add(new User("admin", "admin", "admin"));
    }

    //用户登录查验
    public static boolean login(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                loggedInUser = user;
                return true;
            }
        }
        return false;
    }

    //注册检验
    public static boolean register(String username, String password, String role) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return false; // 用户名已存在
            }
        }
        users.add(new User(username, password, role));
        return true;
    }

    //获取登陆
    public static User getLoggedInUser() {
        return loggedInUser;
    }
}

// 图书类
class Book {
    private String title;//书名
    private String author;//作者
    private String category;//类别
    private boolean isBorrowed;//是否借阅
    private int stock;//库存
    private User borrowedBy; // 当前借阅者信息

    //初始化
    public Book(String title, String author, String category) {
        this.title = title;
        this.author = author;
        this.category = category;
        this.isBorrowed = false;
        this.borrowedBy = null;
    }

//获取书名作者类别等
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCategory() {
        return category;
    }

    public boolean isBorrowed() {
        return isBorrowed;
    }

    public void setBorrowed(boolean borrowed) {
        isBorrowed = borrowed;
    }

    public void setTitle(String text) {
    }

    public void setAuthor(String text) {
    }

    public void setCategory(String text) {
    }

    public User getBorrowedBy() {
        return borrowedBy;
    }

    public void setBorrowedBy(User user) {
        this.borrowedBy = user;
    }

    // 获取库存量的方法
    public int getStock() {
        return stock;
    }
}

// 图书数据管理
class BookManager {
    private static List<Book> books = new ArrayList<>();//存储所有图书
    private static List<String> categories = new ArrayList<>();//存储类别

    static {
        //放图书的类别和信息，从数据库里获取应该
    }

    public static List<Book> getBooks() {
        return books;
    }

    public static List<String> getCategories() {
        return categories;
    }

    public static void addBook(Book book) {
        books.add(book);
    }

//    添加图书
    public static void addCategory(String category) {
        if (!categories.contains(category)) {
            categories.add(category);
        }
    }

//    移除图书
    public static void removeCategory(String category) {
    }

    // 搜索图书的功能，可以按书名、作者或类别进行模糊搜索
    public static List<Book> searchBooks(String query) {
        List<Book> results = new ArrayList<>();
        for (Book book : books) {
            // 假设要匹配书名、作者和类别
            if (book.getTitle().contains(query) || book.getAuthor().contains(query) || book.getCategory().contains(query)) {
                results.add(book);
            }
        }
        return results;// 返回符合条件的图书列表
    }
}

// 登录界面
class LoginUI {
    private JFrame frame;

//    显示登录界面
    public void show() {
        // 主窗口
        frame = new JFrame("图书管理系统 - 登录");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        // 顶部标题
        JLabel titleLabel = new JLabel("图书馆管理系统登录界面", JLabel.CENTER);
        titleLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 32));
        frame.add(titleLabel, BorderLayout.NORTH);

        // 中间表单面板
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // 设置组件之间的间距
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 用户名
        JLabel userLabel = new JLabel("用户名:");
        userLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 24));
        JTextField userText = new JTextField(20);
        userText.setPreferredSize(new Dimension(270, 40));

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(userLabel, gbc);

        gbc.gridx = 1;
        panel.add(userText, gbc);

        // 密码
        JLabel passwordLabel = new JLabel("密码:");
        passwordLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 24));
        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setPreferredSize(new Dimension(270, 40));

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        panel.add(passwordText, gbc);

        // 按钮
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton loginButton = new JButton("登录");
        loginButton.setFont(new Font("Microsoft YaHei", Font.BOLD, 20));
        loginButton.setPreferredSize(new Dimension(120, 50));

        JButton registerButton = new JButton("注册");
        registerButton.setFont(new Font("Microsoft YaHei", Font.BOLD, 20));
        registerButton.setPreferredSize(new Dimension(120, 50));

        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(buttonPanel, gbc);

        frame.add(panel, BorderLayout.CENTER);

        // 底部提示文字
        JLabel footer = new JLabel("请登录或注册账号", JLabel.CENTER);
        footer.setFont(new Font("Microsoft YaHei", Font.ITALIC, 16));
        frame.add(footer, BorderLayout.SOUTH);

        // 添加按钮监听
        loginButton.addActionListener(e -> login(userText.getText(), new String(passwordText.getPassword())));
        registerButton.addActionListener(e -> new RegisterUI().show());

        frame.setVisible(true);
    }


//    登陆逻辑
    private void login(String username, String password) {
        if (UserManager.login(username, password)) {
            frame.dispose();
            new MainUI(UserManager.getLoggedInUser()).show();
        } else {
            JOptionPane.showMessageDialog(frame, "登录失败，请检查用户名和密码。");
        }
    }
}

// 注册界面
class RegisterUI {
    private JFrame frame;

    public void show() {
        frame = new JFrame("图书管理系统 - 注册");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        // 标题
        JLabel titleLabel = new JLabel("注册新账号", JLabel.CENTER);
        titleLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 28));
        frame.add(titleLabel, BorderLayout.NORTH);

        // 主表单面板
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // 控件之间的间距
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 用户名
        JLabel userLabel = new JLabel("用户名:");
        userLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 20));
        JTextField userText = new JTextField(20);
        userText.setPreferredSize(new Dimension(250, 40));

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(userLabel, gbc);

        gbc.gridx = 1;
        panel.add(userText, gbc);

        // 密码
        JLabel passwordLabel = new JLabel("密码:");
        passwordLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 20));
        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setPreferredSize(new Dimension(250, 40));

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        panel.add(passwordText, gbc);

        // 用户类别
        JLabel roleLabel = new JLabel("用户类别:");
        roleLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 20));
        JComboBox<String> roleBox = new JComboBox<>(new String[]{"用户", "管理员"});
        roleBox.setFont(new Font("Microsoft YaHei", Font.PLAIN, 18));
        roleBox.setPreferredSize(new Dimension(250, 40));

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(roleLabel, gbc);

        gbc.gridx = 1;
        panel.add(roleBox, gbc);

        // 注册按钮
        JButton registerButton = new JButton("注册");
        registerButton.setFont(new Font("Microsoft YaHei", Font.BOLD, 20));
        registerButton.setPreferredSize(new Dimension(150, 50));

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER; // 居中对齐
        panel.add(registerButton, gbc);

        // 返回登录按钮
        JButton backButton = new JButton("返回登录");
        backButton.setFont(new Font("Microsoft YaHei", Font.BOLD, 20));
        backButton.setPreferredSize(new Dimension(150, 50));

        gbc.gridy = 4; // 放在注册按钮下方
        gbc.gridwidth = 2; // 跨两列
        gbc.anchor = GridBagConstraints.CENTER; // 居中对齐
        panel.add(backButton, gbc);

        frame.add(panel, BorderLayout.CENTER);

        // 按钮功能-注册
        registerButton.addActionListener(e -> {
            String username = userText.getText();
            String password = new String(passwordText.getPassword());
            String role = (String) roleBox.getSelectedItem();

            if (UserManager.register(username, password, role)) {
                JOptionPane.showMessageDialog(frame, "注册成功！");
                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(frame, "注册失败，用户名可能已存在。");
            }
        });

        // 按钮功能-返回登录
        backButton.addActionListener(e -> {
            frame.dispose(); // 关闭当前窗口
            new LoginUI().show(); // 打开登录界面
        });

        frame.setVisible(true);
    }

}

// 主界面
class MainUI {
    private JFrame frame;
    private User loggedInUser;

//    接收登录用户
    public MainUI(User user) {
        this.loggedInUser = user;
    }

//    显示主界面
    public void show() {
        frame = new JFrame("图书管理系统 - 主界面");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JLabel welcomeLabel = new JLabel("欢迎，" + loggedInUser.getUsername() + " (" + loggedInUser.getRole() + ")", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 20));
        frame.add(welcomeLabel, BorderLayout.NORTH);

        JTabbedPane tabbedPane = new JTabbedPane();

        if (loggedInUser.isAdmin()) {
            tabbedPane.addTab("图书管理", new BookManagementPanel());
            tabbedPane.addTab("类别管理", new CategoryManagementPanel());
        } else {
            tabbedPane.addTab("图书查询", new BookSearchPanel());
            tabbedPane.addTab("我的借阅", new BorrowHistoryPanel(loggedInUser));
        }

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}

// 图书管理界面
class BookManagementPanel extends JPanel {
    private JTable bookTable;
    private BookTableModel tableModel;

//    新增搜索功能
    private JTextField searchField;//搜索框
    private static List<Book> filteredBooks; // 存储查询结果

    public BookManagementPanel() {
        setLayout(new BorderLayout());

        // 初始化查询结果列表为所有图书
        filteredBooks = new ArrayList<>(BookManager.getBooks());

        // 创建搜索栏
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(20);
        JButton searchButton = new JButton("查询");
        searchButton.addActionListener(e -> searchBooks());
        searchPanel.add(new JLabel("搜索:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        // 将搜索栏添加到顶部
        add(searchPanel, BorderLayout.NORTH);

        // 创建表格模型和表格
        tableModel = new BookTableModel();
        bookTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(bookTable);

        // 创建按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addButton = new JButton("添加图书");
        JButton deleteButton = new JButton("删除图书");
        JButton updateButton = new JButton("更新图书");

        // 按钮功能实现
        addButton.addActionListener(e -> showAddBookDialog());
        deleteButton.addActionListener(e -> deleteSelectedBook());
        updateButton.addActionListener(e -> showUpdateBookDialog());

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);

        // 将表格和按钮面板添加到面板中
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // 查询图书（模糊搜索）
    private void searchBooks() {
        String keyword = searchField.getText().trim(); // 获取搜索框输入
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请输入查询关键字！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 调用 BookManager 进行搜索
        List<Book> searchResults = BookManager.getBooks().stream()
                .filter(book -> book.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                        book.getAuthor().toLowerCase().contains(keyword.toLowerCase()) ||
                        book.getCategory().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());

        // 显示搜索结果
        if (searchResults.isEmpty()) {
            JOptionPane.showMessageDialog(this, "未找到相关图书！", "提示", JOptionPane.INFORMATION_MESSAGE);
        } else {
            StringBuilder resultMessage = new StringBuilder("找到以下图书：\n");
            for (Book book : searchResults) {
                resultMessage.append("书名: ").append(book.getTitle()).append("\n")
                        .append("作者: ").append(book.getAuthor()).append("\n")
                        .append("类别: ").append(book.getCategory()).append("\n")
                        .append("是否借出: ").append(book.isBorrowed() ? "已借出" : "可借阅").append("\n\n");
            }

            // 显示结果
            JOptionPane.showMessageDialog(this, resultMessage.toString(), "搜索结果", JOptionPane.INFORMATION_MESSAGE);
        }
    }



    // 显示添加图书的对话框
    private void showAddBookDialog() {
        JTextField titleField = new JTextField(20);
        JTextField authorField = new JTextField(20);
        JTextField categoryField = new JTextField(20);

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("书名:"));
        panel.add(titleField);
        panel.add(new JLabel("作者:"));
        panel.add(authorField);
        panel.add(new JLabel("类别:"));
        panel.add(categoryField);

        int option = JOptionPane.showConfirmDialog(this, panel, "添加图书", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String title = titleField.getText();
            String author = authorField.getText();
            String category = categoryField.getText();

            // 创建并添加新书
            Book newBook = new Book(title, author, category);
            BookManager.addBook(newBook);
            tableModel.fireTableDataChanged();
        }
    }

    // 删除选中的图书
    private void deleteSelectedBook() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow != -1) {
            Book selectedBook = BookManager.getBooks().get(selectedRow);
            BookManager.getBooks().remove(selectedBook);
            tableModel.fireTableDataChanged();
        } else {
            JOptionPane.showMessageDialog(this, "请选择一行图书来删除");
        }
    }

    // 显示更新图书的对话框
    private void showUpdateBookDialog() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow != -1) {
            Book selectedBook = BookManager.getBooks().get(selectedRow);

            JTextField titleField = new JTextField(selectedBook.getTitle(), 20);
            JTextField authorField = new JTextField(selectedBook.getAuthor(), 20);
            JTextField categoryField = new JTextField(selectedBook.getCategory(), 20);

            JPanel panel = new JPanel(new GridLayout(3, 2));
            panel.add(new JLabel("书名:"));
            panel.add(titleField);
            panel.add(new JLabel("作者:"));
            panel.add(authorField);
            panel.add(new JLabel("类别:"));
            panel.add(categoryField);

            int option = JOptionPane.showConfirmDialog(this, panel, "更新图书", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                selectedBook.setTitle(titleField.getText());
                selectedBook.setAuthor(authorField.getText());
                selectedBook.setCategory(categoryField.getText());
                tableModel.fireTableDataChanged();
            }
        } else {
            JOptionPane.showMessageDialog(this, "请选择一行图书来更新");
        }
    }

    // 图书表格模型
    private static class BookTableModel extends AbstractTableModel {
        private final String[] columnNames = {"书名", "作者", "类别", "是否借阅"};

        @Override
        public int getRowCount() {
            return filteredBooks.size();
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            Book book = BookManager.getBooks().get(rowIndex);
            switch (columnIndex) {
                case 0: return book.getTitle();
                case 1: return book.getAuthor();
                case 2: return book.getCategory();
                case 3: return book.isBorrowed() ? "已借出" : "可借阅";
                default: return null;
            }
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }
    }
}


// 类别管理界面
class CategoryManagementPanel extends JPanel {
    private JTextField categoryField;
    private JList<String> categoryList;
    private DefaultListModel<String> categoryListModel;

    public CategoryManagementPanel() {
        setLayout(new BorderLayout());

        // 创建类别输入框
        categoryField = new JTextField(20);
        JButton addButton = new JButton("添加类别");
        JButton deleteButton = new JButton("删除类别");

        // 创建类别列表
        categoryListModel = new DefaultListModel<>();
        categoryList = new JList<>(categoryListModel);
        categoryList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(categoryList);

        // 按钮事件
        addButton.addActionListener(e -> addCategory());
        deleteButton.addActionListener(e -> deleteCategory());

        // 创建输入框和按钮面板
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inputPanel.add(new JLabel("类别名称:"));
        inputPanel.add(categoryField);
        inputPanel.add(addButton);
        inputPanel.add(deleteButton);

        // 布局管理
        add(inputPanel, BorderLayout.NORTH);
        add(listScrollPane, BorderLayout.CENTER);
    }

    // 添加类别
    private void addCategory() {
        String category = categoryField.getText();
        if (!category.isEmpty() && !BookManager.getCategories().contains(category)) {
            // 添加类别到BookManager
            BookManager.addCategory(category);
            // 刷新类别列表
            categoryListModel.addElement(category);
            categoryField.setText("");  // 清空输入框
        } else {
            JOptionPane.showMessageDialog(this, "类别已存在或输入为空");
        }
    }

    // 删除选中的类别
    private void deleteCategory() {
        int selectedIndex = categoryList.getSelectedIndex();
        if (selectedIndex != -1) {
            String category = categoryList.getSelectedValue();
            BookManager.removeCategory(category);
            categoryListModel.removeElement(category);  // 删除类别
        } else {
            JOptionPane.showMessageDialog(this, "请选择一个类别来删除");
        }
    }
}


// 图书查询界面
class BookSearchPanel extends JPanel {
    private JTextField searchField;
    private JButton searchButton;
    private JTable bookTable;
    private DefaultTableModel tableModel;
    private JButton prevButton, nextButton;
    private int currentPage = 1;
    private int booksPerPage = 10;  // 每页显示的图书数量
    private List<Book> searchResults = new ArrayList<>();

    public BookSearchPanel() {
        setLayout(new BorderLayout());

        // 搜索输入框和按钮
        JPanel searchPanel = new JPanel();
        searchField = new JTextField(20);
        searchButton = new JButton("查询");
        searchButton.addActionListener(e -> searchBooks());
        searchPanel.add(new JLabel("搜索图书："));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        add(searchPanel, BorderLayout.NORTH);

        // 创建表格
        tableModel = new DefaultTableModel(new Object[]{"书名", "作者", "类别", "库存量"}, 0);
        bookTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(bookTable);
        add(tableScrollPane, BorderLayout.CENTER);

        // 分页按钮
        JPanel paginationPanel = new JPanel();
        prevButton = new JButton("上一页");
        nextButton = new JButton("下一页");

        prevButton.setEnabled(false);  // 初始时上一页不可用
        prevButton.addActionListener(e -> showPage(currentPage - 1));
        nextButton.addActionListener(e -> showPage(currentPage + 1));

        paginationPanel.add(prevButton);
        paginationPanel.add(nextButton);

        add(paginationPanel, BorderLayout.SOUTH);
    }

    // 搜索图书
    private void searchBooks() {
        String query = searchField.getText();
        if (!query.isEmpty()) {
            // 调用图书管理器进行搜索
            searchResults = BookManager.searchBooks(query);
            currentPage = 1;  // 重置为第一页
            showPage(currentPage);
        } else {
            JOptionPane.showMessageDialog(this, "请输入查询关键字！");
        }
    }

    // 显示指定页的数据
    private void showPage(int page) {
        if (page < 1 || page > getTotalPages()) {
            return;
        }
        currentPage = page;

        // 计算当前页要显示的数据
        int startIndex = (currentPage - 1) * booksPerPage;
        int endIndex = Math.min(startIndex + booksPerPage, searchResults.size());

        // 更新表格内容
        tableModel.setRowCount(0);  // 清空表格
        for (int i = startIndex; i < endIndex; i++) {
            Book book = searchResults.get(i);
            tableModel.addRow(new Object[]{book.getTitle(), book.getAuthor(), book.getCategory(), book.getStock()});
        }

        // 更新分页按钮状态
        prevButton.setEnabled(currentPage > 1);
        nextButton.setEnabled(currentPage < getTotalPages());
    }

    // 获取总页数
    private int getTotalPages() {
        return (int) Math.ceil((double) searchResults.size() / booksPerPage);
    }
}


// 借阅历史界面
// 借阅历史和我的图书借阅状态面板
class BorrowHistoryPanel extends JPanel {
    private User loggedInUser;

    public BorrowHistoryPanel(User loggedInUser) {
        this.loggedInUser = loggedInUser;
        setLayout(new BorderLayout());

        // 创建表格模型
        JTable borrowTable = new JTable(new BorrowHistoryTableModel(loggedInUser));
        JScrollPane scrollPane = new JScrollPane(borrowTable);
        add(scrollPane, BorderLayout.CENTER);

        // 添加借阅操作的按钮
        JPanel buttonPanel = new JPanel();
        JButton borrowButton = new JButton("借阅书籍");
        borrowButton.addActionListener(e -> borrowBook(borrowTable));
        JButton returnButton = new JButton("归还书籍");
        returnButton.addActionListener(e -> returnBook(borrowTable));
        buttonPanel.add(borrowButton);
        buttonPanel.add(returnButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // 借阅书籍的操作
    private void borrowBook(JTable borrowTable) {
        int selectedRow = borrowTable.getSelectedRow();
        if (selectedRow >= 0) {
            Book bookToBorrow = loggedInUser.getBorrowedBooks().get(selectedRow);
            if (bookToBorrow != null && !bookToBorrow.isBorrowed()) {
                loggedInUser.borrowBook(bookToBorrow);
                JOptionPane.showMessageDialog(this, "借阅成功！");
            } else {
                JOptionPane.showMessageDialog(this, "借阅失败，该书已被借出或不存在！");
            }
        } else {
            JOptionPane.showMessageDialog(this, "请选择一本书籍进行借阅！");
        }
    }

    // 归还书籍的操作
    private void returnBook(JTable borrowTable) {
        int selectedRow = borrowTable.getSelectedRow();
        if (selectedRow >= 0) {
            Book bookToReturn = loggedInUser.getBorrowedBooks().get(selectedRow);
            if (bookToReturn != null && bookToReturn.isBorrowed()) {
                loggedInUser.returnBook(bookToReturn);
                JOptionPane.showMessageDialog(this, "归还成功！");
            } else {
                JOptionPane.showMessageDialog(this, "归还失败，未找到该书！");
            }
        } else {
            JOptionPane.showMessageDialog(this, "请选择一本书籍进行归还！");
        }
    }

    // 获取用户选择的书籍，模拟从UI中获取
    private Book getSelectedBook() {
        // 获取用户借阅的书籍
        List<Book> borrowedBooks = loggedInUser.getBorrowedBooks();

        // 检查用户是否有借阅的书籍
        if (borrowedBooks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "没有借阅书籍！");
            return null;
        }

        // 模拟选择书籍的过程
        // 在实际应用中可以通过UI组件获取用户选择的书籍
        return borrowedBooks.get(0);  // 返回第一本书
    }


}

// 借阅历史表格模型
class BorrowHistoryTableModel extends AbstractTableModel {
    private User loggedInUser;
    private List<Book> borrowedBooks;

    public BorrowHistoryTableModel(User loggedInUser) {
        this.loggedInUser = loggedInUser;
        this.borrowedBooks = loggedInUser.getBorrowedBooks();
    }

    @Override
    public int getRowCount() {
        return borrowedBooks.size();
    }

    @Override
    public int getColumnCount() {
        return 3; // 书名、作者、借阅状态
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Book book = borrowedBooks.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return book.getTitle();
            case 1:
                return book.getAuthor();
            case 2:
                return book.isBorrowed() ? "已借阅" : "未借阅";
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "书名";
            case 1: return "作者";
            case 2: return "借阅状态";
            default: return "";
        }
    }
}


// 图书表格模型
class BookTableModel extends AbstractTableModel {
    @Override
    public int getRowCount() {
        return 0;
    }

    @Override
    public int getColumnCount() {
        return 0;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return null;
    } /*...*/ }
